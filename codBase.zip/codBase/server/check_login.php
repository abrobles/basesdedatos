<?php

  require('lib.php');

  $con = new ConectorBD();

  $response['msg'] = $con->initConexion('agenda');

  $resultado = $con->query('SELECT correo FROM usuario where '.$_SESSION['user']);
  $fila = $resultado->fetch_assoc();
  
  if(password_verify(password_hash(.$_SESSION['password'], PASSWORD_DEFAULT), $fila['correo']) 
  {
  echo json_encode($response);	
  }

  $con->cerrarConexion();

 ?>
