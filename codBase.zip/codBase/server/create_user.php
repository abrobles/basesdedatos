<?php

  require('lib.php');

  $con = new ConectorBD();

  if ($con->initConexion('agenda')=='OK') {

    $datos['correo'] = "ab.robles@gmail.com";
    $datos['nombre'] = "Alvaro Robles";
    $datos['contrasenna'] = password_hash("abcd1234", PASSWORD_DEFAULT);;
    $datos['fecha_nacimiento'] = "1978-10-08";

    if ($con->insertData('usuario', $datos)) {
      echo "Se insertaron los datos correctamente";
    }else echo "Se ha producido un error en la inserción";

    $con->cerrarConexion();

  }else {
    echo "Se presentó un error en la conexión";
  }


 ?>
